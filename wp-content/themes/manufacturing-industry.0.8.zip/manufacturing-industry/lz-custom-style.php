<?php 

	$manufacturing_industry_custom_style = '';

	// Logo Size
	$manufacturing_industry_logo_top_margin = get_theme_mod('manufacturing_industry_logo_top_margin');
	$manufacturing_industry_logo_bottom_margin = get_theme_mod('manufacturing_industry_logo_bottom_margin');
	$manufacturing_industry_logo_left_margin = get_theme_mod('manufacturing_industry_logo_left_margin');
	$manufacturing_industry_logo_right_margin = get_theme_mod('manufacturing_industry_logo_right_margin');

	if( $manufacturing_industry_logo_top_margin != '' || $manufacturing_industry_logo_bottom_margin != '' || $manufacturing_industry_logo_left_margin != '' || $manufacturing_industry_logo_right_margin != ''){
		$manufacturing_industry_custom_style .=' .logo {';
			$manufacturing_industry_custom_style .=' margin-top: '.esc_attr($manufacturing_industry_logo_top_margin).'px; margin-bottom: '.esc_attr($manufacturing_industry_logo_bottom_margin).'px; margin-left: '.esc_attr($manufacturing_industry_logo_left_margin).'px; margin-right: '.esc_attr($manufacturing_industry_logo_right_margin).'px;';
		$manufacturing_industry_custom_style .=' }';
	}

	// Site Title Font Size
	$manufacturing_industry_site_title_font_size = get_theme_mod('manufacturing_industry_site_title_font_size');
	if( $manufacturing_industry_site_title_font_size != ''){
		$manufacturing_industry_custom_style .=' .logo h1.site-title, .logo p.site-title {';
			$manufacturing_industry_custom_style .=' font-size: '.esc_attr($manufacturing_industry_site_title_font_size).'px;';
		$manufacturing_industry_custom_style .=' }';
	}

	// Site Tagline Font Size
	$manufacturing_industry_site_tagline_font_size = get_theme_mod('manufacturing_industry_site_tagline_font_size');
	if( $manufacturing_industry_site_tagline_font_size != ''){
		$manufacturing_industry_custom_style .=' .logo p.site-description {';
			$manufacturing_industry_custom_style .=' font-size: '.esc_attr($manufacturing_industry_site_tagline_font_size).'px;';
		$manufacturing_industry_custom_style .=' }';
	}

	// Header Image
	$header_image_url = manufacturing_industry_banner_image( $image_url = '' );
	if( $header_image_url != ''){
		$manufacturing_industry_custom_style .=' #inner-pages-header {';
			$manufacturing_industry_custom_style .=' background-image: url('. esc_url( $header_image_url ).'); background-size: cover; background-repeat: no-repeat; background-attachment: fixed;';
		$manufacturing_industry_custom_style .=' }';
		$manufacturing_industry_custom_style .=' .header-overlay {';
			$manufacturing_industry_custom_style .=' position: absolute; 	width: 100%; height: 100%; 	top: 0; left: 0; background: #000; opacity: 0.3;';
		$manufacturing_industry_custom_style .=' }';
	} else {
		$manufacturing_industry_custom_style .=' #inner-pages-header {';
			$manufacturing_industry_custom_style .=' background:linear-gradient(0deg,#ccc,#0a0607 80%) no-repeat; ';
		$manufacturing_industry_custom_style .=' }';
	}

	$manufacturing_industry_slider_hide_show = get_theme_mod('manufacturing_industry_slider_hide_show',false);
	if( $manufacturing_industry_slider_hide_show == true){
		$manufacturing_industry_custom_style .=' .page-template-custom-home-page #inner-pages-header {';
			$manufacturing_industry_custom_style .=' display:none;';
		$manufacturing_industry_custom_style .=' }';
	} else if( $manufacturing_industry_slider_hide_show == false) {
		$manufacturing_industry_custom_style .=' .page-template-custom-home-page .menu-section {';
			$manufacturing_industry_custom_style .=' position: static; background: rgb(22 29 45 / 60%);';
		$manufacturing_industry_custom_style .=' }';
		$manufacturing_industry_custom_style .=' #features-section {';
			$manufacturing_industry_custom_style .=' margin-top: 20px;';
		$manufacturing_industry_custom_style .=' }';
	}

	// Copyright padding
	$manufacturing_industry_copyright_padding = get_theme_mod('manufacturing_industry_copyright_padding');
	if( $manufacturing_industry_copyright_padding != ''){
		$manufacturing_industry_custom_style .=' .site-info {';
			$manufacturing_industry_custom_style .=' padding-top: '.esc_attr($manufacturing_industry_copyright_padding).'px; padding-bottom: '.esc_attr($manufacturing_industry_copyright_padding).'px;';
		$manufacturing_industry_custom_style .=' }';
	}