<div class="sidebar-area mt-5">
  <?php
    dynamic_sidebar('home-automation-sidebar');
  ?>
</div>